"use strict"

function generateGreeting(name) {
  return "Guten Tag, " + name + "!!"
}

module.exports = generateGreeting