"use strict"

const name = "Max"

console.log("Hallo " + name + "!")
console.log('Hallo ' + name + '!')

console.log(`Hallo ` + name + `!`)
console.log(`Hallo ${name}: ${name.length + 5}!`)