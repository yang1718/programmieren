// Variable "greeting" wird erstellt und ihr wird ein Wert zugewiesen
let greeting = "Hallo Welt!"

// Die Variable "greeting" wird 2x ausgegeben
console.log(greeting)
console.log(greeting)

// Die Variable "greeting" ist bereits erstellt. Der Wert (Inhalt) wird 
// hier überschrieben!
greeting = "Hallo JavaScript!"

// Die Variable "greeting" wird 2x ausgegeben
console.log(greeting)
console.log(greeting)