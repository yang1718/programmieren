"use strict"

// String
let a = 'Hallo Welt!'
console.log(typeof a)
console.log(a)

// Zahlen
let b = 42.5
console.log(typeof b)
console.log(b)

// Booleans (true / false)
let c = true
console.log(typeof c)
console.log(c)

