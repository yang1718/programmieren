console.log("Hallo Welt")
console.log("Hallo JavaScript")