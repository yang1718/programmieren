"use strict"

// console.log(5 + 6)
// console.log("5" + "6")

let water = "1.9"
let amount = 10 + water
console.log(amount)

// console.log("Hallo, " + "JavaScript")

// console.log(true + true)