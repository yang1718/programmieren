// Variable "greeting" wird erstellt
let greeting

// Der Variablen "greeting" wird ein Wert zugewiesen
greeting = "Hallo Welt!"

// Die Variable "greeting2" wird erstellt und ihr wird ein Wert zugewiesen
let greeting2 = "Hallo Welt!"

// Die Variable "greeting2" wird 2x ausgegeben
console.log(greeting2)
console.log(greeting2)