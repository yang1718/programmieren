"use strict"


const moment = require("moment")

const now = moment()

now.add(1, "year")

// now.addYear()