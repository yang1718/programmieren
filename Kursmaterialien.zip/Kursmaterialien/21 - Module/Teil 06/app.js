"use strict"


const variable = []

console.log(Array.isArray(variable))