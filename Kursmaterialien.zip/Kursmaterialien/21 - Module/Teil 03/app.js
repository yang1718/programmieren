"use strict"

const studentsModule = require("./students")
const studentsModule2 = require("./students")

console.log(studentsModule)
console.log(studentsModule2)
/*
const f = require("./a")

f.f()
*/