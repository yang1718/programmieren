"use strict"

require("./a.js")
