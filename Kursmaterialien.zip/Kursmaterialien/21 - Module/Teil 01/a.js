"use strict"

console.log("Ich bin die a.js")

const a = 5

console.log(a + 5)