"use strict"


const f = require("./a.js")

f()
f()
f()