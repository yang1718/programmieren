"use strict"

const data = {
  students: ["Max", "Moritz"],
  numberOfStudents: 2
}

if (data.numberOfStudents <= 2) {
  // PAUSE
  data.students.push("Erika")
  data.numberOfStudents++
}

