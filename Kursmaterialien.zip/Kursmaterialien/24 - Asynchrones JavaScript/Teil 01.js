"use strict"

let zahl = 5

setTimeout(() => {
  console.log(zahl)
}, 1000)

zahl = 6

console.log("Hallo Welt")