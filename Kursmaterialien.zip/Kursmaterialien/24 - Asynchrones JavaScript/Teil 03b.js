"use strict"

if (data.numberOfStudents <= 2) {
  // 
  data.students.push("Tom")
  data.numberOfStudents++
}
