"use strict"

// Wir definieren eine erste Funktion
function sayHello(name) {
  console.log("Hallo " + name + "!")
}

sayHello("Max")
sayHello("Erika")
sayHello("Erika")