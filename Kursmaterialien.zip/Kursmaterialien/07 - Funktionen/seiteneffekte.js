"use strict"

const students = ["Max"]

function addStudent(name) {
  students.push(name)
}

addStudent("Erika")

console.log("students:", students)