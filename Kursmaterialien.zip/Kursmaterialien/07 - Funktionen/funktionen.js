"use strict"

// Wir definieren eine erste Funktion
function sayHello() {
  console.log("Hallo Welt!")
}


sayHello()
sayHello()
sayHello()