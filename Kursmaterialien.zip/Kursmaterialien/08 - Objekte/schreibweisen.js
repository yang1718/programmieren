"use strict"

const student = {
  name: "Max Mustermann",
  age: 21,
  "2019-2020": "Ungarisch",
  "gewünschter Kurs": "Bulgarisch"
}

console.log(student.age)

console.log(student["na" + "me"])
console.log(student["gewünschter Kurs"])