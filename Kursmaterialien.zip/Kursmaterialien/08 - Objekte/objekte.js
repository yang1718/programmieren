"use strict"

/*
const student = {
  "name": "Max Mustermann",
  "age": 21,
  "subject": "Englisch"
}
*/
const student = {
  name: "Max Mustermann",
  age: 21,
  subject: "Englisch"
}

console.log(student.name)
console.log(student.age)
console.log(student.subject)