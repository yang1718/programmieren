"use strict"

const a = "Hallo Welt"

console.log(Math.pow(2, 10))
console.log(2 ** 10)