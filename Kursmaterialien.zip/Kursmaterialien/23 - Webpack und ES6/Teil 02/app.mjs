
import name from "./other.mjs"

console.log(name)