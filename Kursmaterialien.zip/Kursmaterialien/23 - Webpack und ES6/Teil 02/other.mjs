
export const sayHello = function() {
  console.log("sayHello() wurde ausgeführt!")
}

export const sayHello2 = function() {
  console.log("sayHello2() wurde ausgeführt!")
}

export default "Max Mustermann"