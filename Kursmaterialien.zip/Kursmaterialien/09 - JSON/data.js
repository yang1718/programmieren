"use strict"

// https://www.json.org/

// JSON = JavaScript Object Notation

// Von JavaScript nach JSON
const data = [
  {
    "firstname": "Max", 
    "age": 21, 
    "enrolled": true
  },
  {"firstname": "Laura", "age": 35, "enrolled": false}
]

console.log(data)