"use strict"

// Randfälle beachten!

// Ganz Zahl, größer als 0
let numberOfStudents = 5

if (numberOfStudents === 1) {
  console.log("Der Sprachkurs kostet 40€ / Stunde / Teilnehmer")
}
else {
  // numberOfStudents ist eine ganze Zahl, größer als 1 
  // numberOfStudents ist eine ganze Zahl, größer gleich 2
  if (numberOfStudents <= 5) {
    console.log("25€ / Stunde / Teilnehmer")
  }
  else {
    // numberOfStudents ist eine ganze Zahl, größer als 5
    // numberOfStudents ist eine ganze Zahl, größer gleich 6
    console.log("Der Sprachkurs kostet 15€ / Stunde / Teilnehmer")
  }
}