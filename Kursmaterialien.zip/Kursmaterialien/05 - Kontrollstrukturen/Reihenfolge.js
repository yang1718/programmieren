"use strict"

console.log(5 + 3 * 5)

console.log(5 + 5 === 10)

if (
  ((5 + 5) === 10) &&
  ((3 * 5) === 15)
) {

}