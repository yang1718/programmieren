"use strict"

let request = null

request = ""

if (request) {
  console.log("Hallo Welt!")
}