"use strict"

let a = 41

/*
{
  console.log("Zeile 1")
  console.log("Zeile 2")
}
*/

if (a === 42) console.log("Zeile 0!")

if (a === 42) {
  console.log("Zeile 1")
  console.log("Zeile 2")
}