"use strict"

/*
let a = false

if (a) {
  console.log("Hallo Welt!")
}
*/

/*
let zahl1 = 7
let zahl2 = 6

if (zahl1 <= zahl2) {
  console.log("Zahl1 ist kleiner gleich Zahl2!")
}
*/

let students = ["Max", "Moritz"]
if (students.indexOf("Erika") === -1) {
  console.log("Erika nimmt noch nicht am Kurs teil!")
}
