"use strict"

setTimeout(function() {
  console.log("Hallo Welt!")
}, 1000)

setInterval(() => {
  console.log("Hallo Welt!")
}, 1000)