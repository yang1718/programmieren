"use strict"

for (let counter = 0; counter < 5; counter++) {
  console.log(counter)
}

for (let i = 1; i <= 10; i++) {
  console.log("i", i)
}