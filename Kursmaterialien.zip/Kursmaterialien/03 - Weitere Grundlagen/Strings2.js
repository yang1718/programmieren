"use strict"

// Newline
console.log('Hallo\\\nWelt!')

// String wiederholen
console.log("-".repeat(20))

// .slice(start, end)
console.log("Hallo Welt".slice(6, 8))

// .substr(start, length)
console.log("Hallo Welt".substr(6, 2))
