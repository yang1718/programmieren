"use strict"

// Das hier ist ein Kommentar

/* 
Das hier ist auch ein Kommentar 
*/

/** 
 * Das hier ist eine wichtige Begrüßung 
 * 
 * @type string
 */
const message = "Hallo Welt!"

console.log(message)

